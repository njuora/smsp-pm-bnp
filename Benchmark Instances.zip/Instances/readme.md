INTANCES: 

LOW  --> 700 instances.

For each file, the first value is the nubmer of jobs,  the next are p_j for all jobs, and the last value is the value of T.

MOD  --> 700 instances. 

For each file, the first value is the number of jobs,  the next are p_j for all jobs, and the last value is the value of T.



