package algo;

import comn.Base;
import comn.Param;
import comn.ProblemIO;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class AlgoRunner {
    public static ArrayList<Block> findFeasibleBlocks(Instance instance) {
        ArrayList<Block> blocks = new ArrayList<>();
        Block currentBlock = new Block();
        int totalTime = 0;

        backtrack(instance, 0, totalTime, currentBlock, blocks);

        return blocks;
    }

    private static void backtrack(Instance instance, int index, int totalTime, Block currentBlock, List<Block> blocks) {
        if (totalTime > 50) {
            return; // 如果当前 Block 的总处理时间超过 50，直接返回
        }

        if (index == instance.p.length) {
            Block newBlock = new Block(currentBlock);
            if (totalTime != currentBlock.processingTime) {
                System.err.println("ERROR! total Time not equal to block's processingTime");
                System.out.println(currentBlock.toString());
            }
            blocks.add(newBlock);// 找到一个可行的 Block，加入到结果中
            return;
        }

        // 尝试将当前作业加入当前 Block
        if (totalTime + instance.p[index] <= 50) {
            currentBlock.add(index, instance);
            backtrack(instance, index + 1, totalTime + instance.p[index], currentBlock, blocks);
            int jobIndex = currentBlock.get(currentBlock.size() - 1);
            currentBlock.remove(currentBlock.size() - 1);
            currentBlock.processingTime -= instance.p[jobIndex];
            // currentBlock.remove(Integer.valueOf(jobIndex), instance);
            // currentBlock.remove(currentBlock.size() - 1); // 回溯，移除最后一个作业

        }

        // 不将当前作业加入当前 Block，继续尝试下一个作业
        backtrack(instance, index + 1, totalTime, currentBlock, blocks);
    }

    /**
     * T 不取决于数据集里的T
     * 而是根据给定的固定的50 100 150 200等
     * @param T
     * @param args
     * @throws GRBException
     */
    public void runByFixedT(String dataSetName, int T, String[] args) throws GRBException {
        initialParams();
        initialAlgoComponentParamsByT(T);
        String experimentCondition = "baseline" + "-T=" +T;
        modifyAlgoComponentParams(experimentCondition);
        preparePaths();
        ProblemIO.makeFolders();  // create different folders
        ProblemIO.writeCSV(generateCsvHeaderLine(), true); // make the CSVTitle of abstract result of all instances
        Instance[] instances = readInstances();
        switch (Param.algoName) {
            case "MixedIntegerLinearProgramming":
                runModelGurobi(instances);
                break;
            case "MixedIntegerLinearProgramming-2Stage":
                runModelGurobi2Stage(instances, args);
                break;
            case "BranchAndPrice":
                runBranchAndBound(instances, args);
                break;
            case "Test":
                runTestRoot(instances);
            default:
                System.err.println("No such method");
                break;
        }
    }

    public void run(String[] args) throws GRBException {
        String algoName = args[0]; // "BranchAndPrice" || "MixedIntegerLinearProgramming-2Stage";
        String dataSetName = args[1]; // "" "MOBat Low2010-T2D-x-test" "LOW-differentT" "Test-algo"
        Param.algoName = algoName;
        Param.dataSetName = dataSetName;
        initialParams();
        initialAlgoComponentParams();
        String experimentCondition = "baseline";
        // String experimentCondition = "with-branchRule2+3";
        // String experimentCondition = "baseline-from334append";
        // String experimentCondition = "solveZeroOneKnapsack";

        modifyAlgoComponentParams(experimentCondition);
        preparePaths();
        ProblemIO.makeFolders();  // create different folders
        ProblemIO.writeCSV(generateCsvHeaderLine(), true); // make the CSVTitle of abstract result of all instances
        Instance[] instances = readInstances();
        switch (Param.algoName) {
            case "MixedIntegerLinearProgramming":
                runModelGurobi(instances);
                break;
            case "MixedIntegerLinearProgramming-2Stage":
                runModelGurobi2Stage(instances, args);
                break;
            case "BranchAndPrice":
                runBranchAndBound(instances, args);
                break;
            case "Test":
                runTestRoot(instances);
            default:
                System.err.println("No such method");
                break;
        }
    }

    private void initialParams() {
        Param.debug = getDebugModel();
        Param.dataPath = getDataPath();
        Param.resultPath = getResultPath();
        Param.nThreads = 1;
        Param.problemName = "singleMachineScheduling";
        Param.instancePrefix = "";
        Param.instanceSuffix = "";
        /**
         * 为了测试MOD-hard三个算例，这三个算例3600s跑不出来
         */
        Param.timeLimit = 60 * 60; // for server
        // Param.timeLimit = 35; // for test in local
    }

    /**
     * when experiment condition is baseline
     * the algo components are initialized
     */
    private void initialAlgoComponentParamsByT(int T) {
        Param.experimentCondition = "baseline";
        // ===================two different branch order===============//
        Param.branchBy123Order = true;
        Param.branchBy213Order = false;
        // ===================two different branch order===============//
        // ===================three different branch rule==================//
        Param.branch1OnNumBlocks = true;
        Param.branch2OnY = true;
        Param.branch3OnPairs = true;
        // ===================three different branch rule==================//
        Param.tightenTBound = false;
        Param.useHeuristics = true;
        Param.enableFathomingRuleCheck = true;
        Param.solveContinuousKnapsack = true;
        Param.solveZeroOneKnapsack = false;
        Param.T = T; // 如果不是那些算例的 可以自己定200
        Param.t = 0;
    }

    private void initialAlgoComponentParams() {
        Param.experimentCondition = "baseline";
        // ===================two different branch order===============//
        Param.branchBy123Order = true;
        Param.branchBy213Order = false;
        // ===================two different branch order===============//
        // ===================three different branch rule==================//
        Param.branch1OnNumBlocks = true;
        Param.branch2OnY = true;
        Param.branch3OnPairs = true;
        // ===================three different branch rule==================//
        Param.tightenTBound = false;
        Param.useHeuristics = true;
        Param.enableFathomingRuleCheck = true;
        Param.solveContinuousKnapsack = true;
        Param.solveZeroOneKnapsack = false;
        Param.T = 100;
        Param.t = 0;
    }

    private void modifyAlgoComponentParams(String experimentCondition) {
        Param.experimentCondition = experimentCondition;
        switch (experimentCondition) {
            case "branchRuleBy213Order" -> {
                Param.branchBy123Order = false;
                Param.branchBy213Order = true;
            }
            case "with-branchRule1+3" -> {
                Param.branch2OnY = false;
            }
            case "with-branchRule2+3" -> {
                Param.branch1OnNumBlocks = false;
            }
            case "with-branchRule3" -> {
                Param.branch1OnNumBlocks = false;
                Param.branch2OnY = false;
            }
            case "no-Primal" -> {
                Param.useHeuristics = false;
            }
            case "no-fathoming" -> {
                Param.enableFathomingRuleCheck = false;
            }
            case "solveZeroOneKnapsack" -> {
                Param.solveContinuousKnapsack = false;
                Param.solveZeroOneKnapsack = true;
            }
        }
    }

    private void preparePaths() {
        Param.algoPath = Param.resultPath + "/" + Param.algoName;
        Param.solPath = Param.algoPath + "/" + Param.dataSetName + "/sol";
        Param.csvPath = Param.algoPath + "/" + Param.dataSetName;
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmm");
        String timeStr = now.format(formatter);

        if (Param.debug) {
            Param.csvPath += "/" + Param.algoName + ".csv";
        } else {
            Param.csvPath += "/" + Param.algoName + "-" + Param.experimentCondition + "-" + timeStr + ".csv";
        }
    }

    private boolean getDebugModel() {
        // return true; // during the first debug phase
        return false; // in the server
    }

    private String selectAlgoName() {
        // return "BranchAndPrice";
        // return "MixedIntegerLinearProgramming";
        return "MixedIntegerLinearProgramming-2Stage";
        // return "Test";
    }

    private String selectDataSetName() {
        // return "Bat Low2010-T1"; // LOW Set(T~U[150,200])
        return "Bat Low2010-T2"; // MOD Set(T~U[50,100])
        // return "Test-algo"; // 这个是LOW的前250个，用于测试
        // return "MOD-hard"; // 3600s内三个算例跑不出来，后续设置3600s * 24
        // return "LOW-x";
        // return "LOW-x-test";
        // return "MOD-x";
        // return "MOD-x-test";
     }

    private String getDataPath() {
        return "./data/" + Param.dataSetName;
    }

    private String getResultPath() {
        return "./result"; // server;
        // return "./result_macbook"; // default;
    }

    boolean belongToTest(Instance inst) {
        // Param.instancePrefix = "L_00000404";
        return inst.instName.startsWith(Param.instancePrefix);

    }

    public Instance[] readInstances() {
        File[] files = ProblemIO.getDataFiles();
        Instance[] instances = new Instance[files.length];
        for (int i = 0; i < files.length; i++) {
            String[] strings = ProblemIO.read(files[i]);
            Data data = new Data(files[i].getName(), strings);
            instances[i] = new Instance(data);
        }
        // due to linux, instances will be disturbed randomly
        Arrays.sort(instances);
        return instances;
    }

    String generateCsvHeaderLine() {
        String title = "instName, numOfJobs, T, t, numOfThreads, timeLimit, feasible, optimal, globalUB, globalLB, gap,";
        if (Param.algoName.equals("MixedIntegerLinearProgramming")) {
            // in the minimization problem, objVal -> globalUB, objBound -> globalLB
            title += "timeCost, timeOnModel, timeOnOptimize, " +
                    "numOfNodes," +
                    "numOfVariables, numOfConstraints, gurobiModelStatus";
        }
        if (Param.algoName.equals("MixedIntegerLinearProgramming-2Stage")) {
            title += "stage1Optimal," + "timeCost," +
                    "tBuildModel1, tOptModel1, numNodesModel1," +
                    "numVariablesModel1, numConstraintsModel1, gurobiModel1Status," +
                    "tBuildModel2, tOptModel2, numNodesModel2," +
                    "numVariablesModel2, numConstraintsModel2, gurobiModel2Status";
        }
        if (Param.algoName.equals("BranchAndPrice")) {
            title += "rootUB, rootLB, " +
                    "timeCost, timeOnRoot, timeOnCG, timeOnRMP, timeOnPP, timeOnHeuristics, " +
                    "cntRMPCall, cntPPCall, cntHeuristicsCall, " +
                    "numOfNodes, numOfNodesSolved, numOfNodesRemained, numOfNodesPrunedByInfeasible, numOfNodesPrunedByBound, numOfNodesPrunedByOptimal, " +
                    "numOfLabels, numOfLabelsPrunedByLb, numOfLabelsDominated";
        }
        return title;
    }

    /**
     * add the abstract result of each instance to the result folder
     * add the detailed solution of each instance to the result/sol folder
     *
     * @param instName
     * @param csv
     * @param sol
     * @param feasible
     */
    void writeResult(String instName, String csv, Solution sol, boolean feasible) {
        // CSV文件里的title已经写过了，所以每次只需要添加一行结果就好
        ProblemIO.writeCSV(csv, false);

        // to write the detailed result of each instance to the result/algo/sol folder
        String solPath = Param.solPath + "/" + instName;
        // String solPath = Param.algoPath + "/sol/" + Param.problemName + "_sol_" + instName + "_"  + ".csv";
        File solFile = new File(solPath);
        ProblemIO.writeToFile(solFile, sol.toString());
    }

    void runModelGurobi(Instance[] instances) throws GRBException {
        int index74 = 74; // for 47 debug
        for (int i = index74; i < instances.length; i++) {
            Instance instance = instances[i];
            if (!belongToTest(instance)) {
                continue;
            }
            Base.renewRandom();
            ModelGurobi modelGurobi = new ModelGurobi(instance);
            String startMILP = "\n" + "=".repeat(30) + "Gurobi to solve MILP model: " + instance.instName + "start!" + "=".repeat(30);
            System.out.println(startMILP);
            modelGurobi.run(Param.timeLimit);
            writeResult(instance.instName, modelGurobi.makeCsvItem(), modelGurobi.solution, modelGurobi.feasible);
            if (Param.debug) {
                String endMILP = modelGurobi.makeCsvItem();
                System.out.println(endMILP);
            }
            modelGurobi.end();
        }
    }

    void runModelGurobi2Stage(Instance[] instances, String[] args) throws GRBException {
        int startIndex = 0;
        int endIndex = instances.length;
        if (args.length > 2) {
            String range = args[2];
            String[] parts = range.split("-");
            startIndex = Integer.parseInt(parts[0]);
            endIndex = Integer.parseInt(parts[1]);
        }
        for (int i = startIndex; i < endIndex; i++) {
            Instance instance = instances[i];
            if (!belongToTest(instance)) {
                continue;
            }
            Base.renewRandom();
            TwoStageModelGurobi modelGurobi2Stage = new TwoStageModelGurobi(instance);
            String start2StageMILP = "\n" + "=".repeat(30) + "Gurobi to solve MILP-2Stage model: " + instance.instName + "start!" + "=".repeat(30);
            System.out.println(start2StageMILP);
            modelGurobi2Stage.run(Param.timeLimit);
            writeResult(instance.instName, modelGurobi2Stage.generateSolveResultCsvLine(), modelGurobi2Stage.solution, modelGurobi2Stage.feasible);
            if (Param.debug) {
                String endMILP = modelGurobi2Stage.generateSolveResultCsvLine();
                System.out.println(endMILP);
            }
            modelGurobi2Stage.end();
        }
    }

    void runBranchAndBound(Instance[] instances, String[] args) throws GRBException {
        int startIndex = 0;
        int endIndex = instances.length;
        if (args.length > 2) {
            String range = args[2];
            String[] parts = range.split("-");
            startIndex = Integer.parseInt(parts[0]);
            endIndex = Integer.parseInt(parts[1]);
        }
        for (int i = startIndex; i < endIndex; i++) {
            Instance instance = instances[i];
            if (!belongToTest(instance)) {
                continue;
            }
            Base.renewRandom();
            BranchAndBound bnp = new BranchAndBound(instance);
            String startBnp = "\n" + "=".repeat(30) + "B&P to solve: " + instance.instName + "start!" + "=".repeat(30);
            System.out.println(startBnp);

            bnp.run(Param.timeLimit);
            writeResult(instance.instName, bnp.makeCSVItem(), bnp.incumbentSol, true);
            if (Param.debug) {
                String endBnp = bnp.makeCSVItem();
                System.out.println(endBnp);
            }
            bnp.columnGeneration.master.end();
            System.gc();
        }
    }

    /**
     * When T = 50, According to old Heuristics,
     * two conflict column will be selected simultaneously
     *
     * @param instances
     * @throws GRBException
     */
    void runTestRoot(Instance[] instances) throws GRBException {
        for (int i = 0; i < instances.length; i++) {
            Instance instance = instances[i];
            if (!belongToTest(instance)) {
                continue;
            }

            Base.renewRandom();
            Master master = new Master(instance);
            ArrayList<Block> allBlocks = findFeasibleBlocks(instance);
            System.out.println("the all blocks add to the root node:  " + allBlocks.size());
            for (Block block : allBlocks) {
                System.out.println(block.toString());
            }
            master.addColumns(allBlocks);
            master.model.optimize();
            boolean feasible = (master.model.get(GRB.IntAttr.Status) == GRB.OPTIMAL);
            if (feasible) {
                System.out.println("master : objVal = " + String.format("%.8f", master.getObjValue()) +
                        "  colSize = " + master.columnPool.size());
            }
            System.out.println(master.getLPSol());

        }
    }
}
