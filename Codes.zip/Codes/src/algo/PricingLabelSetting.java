package algo;

import comn.Base;
import comn.Param;
import java.util.*;

public class PricingLabelSetting {
    Instance instance;
    int nJobs;

    Node node;

    ArrayList<Integer> yOne;
    int[][] andJobs;
    boolean[][] orJobs;
    BitSet removedJobs;

    int[] mergedP; // get mergedDuration according to (a,b) branch information and p[]
    double[] mergedDuals; // get mergedValue according to (a,b) branch information and duals[]

    double[] duals;
    /**
     * Algorithm Parameters
     */
    SearchDirection searchDirection;
    int maxNumOfBlocks;
    /* boolean useLSWithRelaxedDRBeforeExactLS;
    boolean useLSWithDSSR;
    boolean useTsp;
    boolean useDominatedAttribute; */


    /**
     * the results of label setting
     * (1): the new Columns
     * (2): the most negative block
     * (3): the most negative reduced cost (as the ub) each new Label's rc must <= ub
     */
    ArrayList<Block> newBlocks;
    Block mostNegativeBlock;
    double reducedCostUB;


    long bnpStartTime;
    long bnpTimeLimit;
    private static final int TIMEOUT_FLAG = -2; // 定义一个新的标志用于超时


    double timeCost;
    double timeOnLowerBound;
    double timeOnDominanceRule;

    long numOfLabels;
    long numOfLabelsPrunedByLb;
    long numOfLabelsDominated;

    // boolean enableDominanceRuleCheck;
    boolean enableFathomingRuleCheck;
    boolean solveContinuousKnapsack;
    boolean solveZeroOneKnapsack;
    // boolean firstDominanceSecondPrunedByBound;
    // boolean firstPrunedByBoundSecondDominance;


    enum SearchDirection {
        FORWARD, BACKWARD, BIDIR
    }

    enum Direction {
        FORWARD, BACKWARD
    }


    public PricingLabelSetting(Instance instance) {
        this.instance = instance;
        this.nJobs = instance.nJobs;

        this.mergedP = new int[nJobs];
        this.mergedDuals = new double[nJobs];
        this.newBlocks = new ArrayList<>();

        this.searchDirection = SearchDirection.FORWARD;
        // this.searchDirection = SearchDirection.BIDIR;
        this.maxNumOfBlocks = 50; // 这个可以替换 比如32等等
        this.enableFathomingRuleCheck = Param.enableFathomingRuleCheck;
        this.solveContinuousKnapsack = Param.solveContinuousKnapsack;
        this.solveZeroOneKnapsack = Param.solveZeroOneKnapsack;
    }

    public void set(Node node) {
        this.node = node;
        this.yOne = node.yOne;
        this.andJobs = node.andJobs;
        this.orJobs = node.orJobs;
        this.removedJobs = node.removedJobs;
    }

    public void solve(double[] duals, long bnpStartTime, long bnpTimeLimit) {
        long s0 = System.currentTimeMillis();

        this.duals = duals;
        this.bnpStartTime = bnpStartTime;
        this.bnpTimeLimit = bnpTimeLimit;

        this.timeCost = 0;
        this.timeOnLowerBound = 0;
        this.timeOnDominanceRule = 0;

        newBlocks.clear();
        this.mostNegativeBlock = null;
        this.reducedCostUB = 0;
        Arrays.fill(mergedP, 0);
        Arrays.fill(mergedDuals, 0); // 初始化都为0 被合并到别的里面的job就不会被更新，值就是0
        for (int i = 0; i < andJobs.length; i++) {
            if (removedJobs.get(i)) {
                continue;
            }
            for (int job : andJobs[i]) {
                this.mergedP[i] += instance.p[job];
                this.mergedDuals[i] += duals[job];
            }
        }
        runLabelSetting();
        timeCost = Base.getTimeCost(s0);
        node.timeOnPP += timeCost;
        node.cntPPCall++;
    }

    private void runLabelSetting() {
        switch (searchDirection) {
            case FORWARD -> forwardLabelSetting();
        }
    }

    private void forwardLabelSetting() {
        PriorityQueue<Label> unexplored = new PriorityQueue<>(Comparator.comparing(label -> label.reducedCost));
        // PriorityQueue<Label> unexplored = new PriorityQueue<>(Comparator.comparing(label -> label.processingTime));

        ArrayList<Label>[] states = new ArrayList[nJobs];
        double[] minCost = new double[nJobs];
        for (int i = 0; i < nJobs; i++) {
            if (removedJobs.get(i)) {
                continue;
            }
            states[i] = new ArrayList<>();
        }
        Arrays.fill(minCost, Integer.MAX_VALUE);
        /*
        crate a initial label
         */
        createInitialLabel(unexplored, Direction.FORWARD);
        /**
         * start extend tree
         */
        while (!Base.timeIsOut(this.bnpStartTime, this.bnpTimeLimit) && !unexplored.isEmpty() && newBlocks.size() <= maxNumOfBlocks) {
            Label label = unexplored.poll();
            if (label.dominated) {
                continue;
            }
            extend(unexplored, states, minCost, label, Direction.FORWARD);
            addEnd(label, Direction.FORWARD);
        }

    }

    /**
     * if direction == forward  -> curJob = 0, reduced cost = T+t-dual[n+1]-dual[n+2]
     * if direction == backward -> curJob = n, reduced cost = 0
     * @param unexplored
     * @param direction
     */
    private void createInitialLabel(PriorityQueue<Label> unexplored, Direction direction) {
        int curJob = (direction == Direction.FORWARD ? -1 : nJobs); // dummy job, maintenance; keep i < j
        int processingTime = 0;
        double reducedCost = (direction == Direction.FORWARD ?
                (instance.T + instance.t - duals[nJobs + 1] - duals[nJobs + 2]) : 0);
        BitSet containJobs = new BitSet(nJobs);
        BitSet nextJobs = new BitSet(nJobs); // 在初始化的nextJobs，那些被合并的job就已经不会出现了。
        for (int i = 0; i < nJobs; i++) {
            if (yOne.contains(i)) {
                continue;
            }
            if (removedJobs.get(i)) {
                continue;
            }
            if (mergedDuals[i] < Base.EPS) {
                continue;
            }
            nextJobs.set(i);
        }
        Label label = new Label(curJob, processingTime, reducedCost, containJobs, nextJobs);
        unexplored.add(label);
    }

    public void extend(PriorityQueue<Label> unexplored, ArrayList<Label>[] states,
                       double[] minCosts, Label parent, Direction dir) {
        for (int j = parent.nextJobs.nextSetBit(0); j >= 0; j = parent.nextJobs.nextSetBit(j + 1)) {
            if (parent.processingTime + mergedP[j] > instance.T) {
                continue;
            }
            Label label = createLabel(parent, j, dir);
            numOfLabels++;
            if (enableFathomingRuleCheck == true) {//
                boolean pruned = isPrunedByLB(label, dir);
                if (pruned) {
                    numOfLabelsPrunedByLb++;
                    continue;
                }
                unexplored.add(label);
                states[j].add(label);
                minCosts[j] = Math.min(minCosts[j], label.reducedCost);
            } else if (enableFathomingRuleCheck == false) {
                unexplored.add(label);
                states[j].add(label);
                minCosts[j] = Math.min(minCosts[j], label.reducedCost);
            }
        }
    }

    private Label createLabel(Label parent, int j, Direction dir) {
        int processingTime = parent.processingTime + mergedP[j];
        double reducedCost = parent.reducedCost - mergedDuals[j];
        BitSet containJobs = (BitSet) parent.containJobs.clone();
        BitSet nextJobs = (BitSet) parent.nextJobs.clone();
        containJobs.set(j); // 此处放的是合并之后的job j 想要获得真实的，还需要倒推。但是只需要在最后的时候考虑就好了
        nextJobs.clear(j);
        if (dir == Direction.FORWARD) {
            nextJobs.clear(parent.curJob + 1, j); // [parent.curJob + 1 ,j)
            for (int h = nextJobs.nextSetBit(j + 1); h >= 0; h = nextJobs.nextSetBit(h + 1)) {
                if (orJobs[h][j] || mergedP[h] + processingTime > instance.T) {
                    nextJobs.clear(h);
                }
            }
        } else if (dir == Direction.BACKWARD) {
            nextJobs.clear(j + 1, parent.curJob); // [j + 1, parent.curJob) parent.curJob这个位置在parent的时候已经被clear了
            for (int h = nextJobs.nextSetBit(0); h >=0 && h < j; h = nextJobs.nextSetBit(h + 1)) {
                if (orJobs[h][j] || mergedP[h] + processingTime > instance.T) {
                    nextJobs.clear(h);
                }
            }
        }
        Label label = new Label(j, processingTime, reducedCost, containJobs, nextJobs);
        return label;
    }

    private void addEnd(Label label, Direction dir) {
        if (label.curJob == -1 || label.curJob == nJobs) {
            return;
        }// dummy job
        double cost = label.reducedCost;
        if (dir == Direction.BACKWARD) {
            cost += (instance.T + instance.t - duals[nJobs + 1] - duals[nJobs + 2]);
        }
        if (cost + Base.EPS < Math.min(0, reducedCostUB)) {
            Block block = new Block();
            for (int i = 0; i < nJobs; i++) {
                if (label.containJobs.get(i)) {
                    for (int j : andJobs[i]) {
                        block.add(j, instance);
                    }
                }
            }
            newBlocks.add(block);
            if (cost + Base.EPS < reducedCostUB) {
                reducedCostUB = cost;
                mostNegativeBlock = block;
            }

            if (Param.debug) {
                if (!node.isValid(block)) {
                    System.err.println("error: invalid block");
                }
                if (!block.isFeasible(instance)) {
                    System.err.println("error: infeasible block");
                }
            }
        }
    }

    boolean isPrunedByLB(int i, double[] fminCost, int j, double[] bminCost) {
        double lb = fminCost[i] + bminCost[j];
        return lb + Base.EPS >= Math.min(0, reducedCostUB);
    }

    boolean isPrunedByLB(Label flabel, int j, double[] bminCost) {
        double lb = flabel.reducedCost + bminCost[j];
        return lb + Base.EPS >= Math.min(0, reducedCostUB);
    }

    /**
     * 理论是上去求label的精确的lb但是没有必要，因为精确求解很慢
     * 所以还是求解的松弛后的lb
     * @param label
     * @param dir
     * @return
     */
    private boolean isPrunedByLB(Label label, Direction dir) {
        long s0 = System.currentTimeMillis();
        double lb = computeLBOnCost(label, dir);
        timeOnLowerBound += Base.getTimeCost(s0);
        return lb + Base.EPS >= Math.min(0, reducedCostUB);
    }

    private double computeLBOnCost(Label label, Direction dir) {
        int[] weights = new int[nJobs];
        double[] values = new double[nJobs];
        int cnt = 0;
        for (int j = 0; j < nJobs; j++) {
            if (label.nextJobs.get(j) && mergedDuals[j] > 0) {
                weights[cnt] = mergedP[j];
                values[cnt] = mergedDuals[j];
                cnt++;
            }
        }
        weights = Arrays.copyOfRange(weights, 0, cnt);
        values = Arrays.copyOfRange(values, 0, cnt);
        int capacity = instance.T - label.processingTime;
        double maxValue = 0;
        if (solveContinuousKnapsack) {
            maxValue = solveContinuousKnapsack(capacity, weights, values);
        }
        if (solveZeroOneKnapsack) {
            int[] intValues = Arrays.stream(values).mapToInt(v -> (int)Math.round(v)).toArray();
            maxValue = solveZeroOneKnapsack(capacity, weights, intValues);
        }
        double lb = label.reducedCost - maxValue;
        if (dir == Direction.BACKWARD) {
            lb += (instance.T + instance.t - duals[nJobs + 1] - duals[nJobs + 2]);
        }
        return lb;
    }

    /**
     * 本来可以去精确求解，但是这里可以去求一个lb的下界 所以这里其实是去求一个最大值的上界
     * @param capacity
     * @param weights
     * @param values
     * @return
     */
    private double solveContinuousKnapsack(int capacity, int[] weights, double[] values) {
        int size = weights.length;
        // sort items in DESC of v[j]/w[j]
        Integer[] items = new Integer[size];
        for (int i = 0; i < size; i++) {
            items[i] = i;
        }
        Arrays.sort(items, Comparator.comparingDouble(o -> -(values[o] / weights[o])));
        double leftSpace = capacity;
        double totalValue = 0;
        for (int i : items) {
            if (values[i] <= 0) break;
            // take the largest possible value
            if (leftSpace - weights[i] >= 0) {
                leftSpace -= weights[i];
                totalValue += values[i];
            } else {
                totalValue += leftSpace / weights[i] * values[i];
                break;
            }
        }
        return totalValue;
    }

    /**
     * 用精确求解的方式 直接进行求解
     * @param capacity
     * @param weights
     * @param values
     * @return
     */
    private int solveZeroOneKnapsack(int capacity, int[] weights, int[] values) {
        int n = weights.length;
        // dp[i][j]: using first i items with total capacity j, the max value
        int[][] dp = new int[n + 1][capacity + 1];

        for (int i = 1; i <= n; i++) {
            int w = weights[i - 1];
            int v = values[i - 1];
            for (int j = 0; j <= capacity; j++) {
                if (j >= w) {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - w] + v);
                } else {
                    dp[i][j] = dp[i - 1][j];
                }
            }
        }

        return dp[n][capacity];
    }

    public boolean findNewBlocks() {
        return !newBlocks.isEmpty();
    }

    class Label {
        int curJob;
        int processingTime;
        double reducedCost;
        BitSet containJobs;
        BitSet nextJobs; // 未来可以拓展的job

        double lb; // 根据当前的cost以及未来的nextJobs所可能带来的reducedCost的下界
        boolean dominated;

        public Label(int curJob, int processingTime, double reducedCost, BitSet containJobs, BitSet nextJobs) {
            this.curJob = curJob;
            this.processingTime = processingTime;
            this.reducedCost = reducedCost;
            this.containJobs = containJobs;
            this.nextJobs = nextJobs;
        }

        @Override
        public String toString() {
            return "(" + curJob + ", " + processingTime + ", " + reducedCost + ", " + containJobs.toString() + ")";
        }
    }

}