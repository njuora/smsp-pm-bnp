package algo;

import com.gurobi.gurobi.*;
import comn.Base;
import comn.Param;

/**
 * @author FeiAiYue
 * @date 2025-04-20-21:36
 * @description
 */
public class TwoStageModelGurobi {
    public double timeLimit;
    public double timeOnBuildModelStage1;
    public double timeOnOptimizeModelStage1;
    public double timeOnBuildModelStage2;
    public double timeOnOptimizeModelStage2;
    public Solution solution;
    public boolean feasible;
    public boolean stage1Optimal;
    public boolean optimal;
    double gap;
    Instance instance;
    int N;
    int[] p;
    int T;
    int t;
    GRBEnv env;
    GRBModel modelStage1;
    GRBModel modelStage2;

    GRBVar[][] x;
    GRBVar[] y;


    public TwoStageModelGurobi(Instance instance) throws GRBException {
        this.env = new GRBEnv(true);
        this.instance = instance;
        this.N = instance.nJobs;
        this.p = instance.p;
        this.T = instance.T;
        this.t = instance.t;
        this.solution = new Solution();
    }

    /**
     * build Stage Model 1 to get the minimal blocks
     * @throws GRBException
     */
    public void buildModelStage1() throws GRBException {
        long start = System.currentTimeMillis();
        modelStage1 = new GRBModel(env);

        // create the decision variables

        x = new GRBVar[N][N];
        y = new GRBVar[N];

        for (int j = 0; j < N; j++) {
            y[j] = modelStage1.addVar(0, 1, 1.0, GRB.BINARY, "y_" + j);
            for (int i = 0; i < N; i++) {
                x[i][j] = modelStage1.addVar(0, 1, 0.0, GRB.BINARY, "x_" + i + "_" + j);
            }
        }
        // constraint: each job assigned once
        for (int i = 0; i < N; i++) {
            GRBLinExpr expr = new GRBLinExpr();
            for (int j = 0; j < N; j++) {
                expr.addTerm(1.0, x[i][j]);
            }
            modelStage1.addConstr(expr, GRB.EQUAL, 1.0, "assign_" + i);
        }

        // constraint: total processing time per batch <= T
        for (int j = 0; j < N; j++) {
            GRBLinExpr expr = new GRBLinExpr();
            for (int i = 0; i < N; i++) {
                expr.addTerm(p[i], x[i][j]);
            }
            GRBLinExpr rhs = new GRBLinExpr();
            rhs.addTerm(T, y[j]);
            modelStage1.addConstr(expr, GRB.LESS_EQUAL, rhs, "time_" + j);
        }

        // constraint: y_i >= y_{i+1}
        for (int i = 0; i < N - 1; i++) {
            modelStage1.addConstr(y[i], GRB.GREATER_EQUAL, y[i + 1], "yOrder_" + i);
        }

        // objective: minimize sum of y_i
        GRBLinExpr obj1 = new GRBLinExpr();
        for (int i = 0; i < N; i++) {
            obj1.addTerm(1.0, y[i]);
        }
        modelStage1.setObjective(obj1, GRB.MINIMIZE);
        timeOnBuildModelStage1 = 0.001 * (System.currentTimeMillis() - start);
    }

    public void buildModelStage2(int L) throws GRBException {
        long start = System.currentTimeMillis();
        this.modelStage2 = new GRBModel(env);

        x = new GRBVar[N][L];

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < L; j++) {
                x[i][j] = modelStage2.addVar(0, 1, 0.0, GRB.BINARY, "x_" + i + "_" + j);
            }
        }

        // constraint: each job assigned once
        for (int i = 0; i < N; i++) {
            GRBLinExpr expr = new GRBLinExpr();
            for (int j = 0; j < L; j++) {
                expr.addTerm(1.0, x[i][j]);
            }
            modelStage2.addConstr(expr, GRB.EQUAL, 1.0, "assign2_" + i);
        }

        // constraint: total processing time per batch <= T
        for (int j = 0; j < L; j++) {
            GRBLinExpr expr = new GRBLinExpr();
            for (int i = 0; i < N; i++) {
                expr.addTerm(p[i], x[i][j]);
            }
            modelStage2.addConstr(expr, GRB.LESS_EQUAL, T, "time2_" + j);
        }


        // minimize makeSpan
        GRBLinExpr obj2 = new GRBLinExpr();
        for (int i = 0; i < N; i++) {
            obj2.addTerm(p[i], x[i][L - 1]);
        }
        obj2.addConstant((T + t) * (L - 1));

        modelStage2.setObjective(obj2, GRB.MINIMIZE);
        timeOnBuildModelStage2 = 0.001 * (System.currentTimeMillis() - start);

    }

    public void run(int timeLimit) {
        this.timeLimit = timeLimit;
        try {
            env.set(GRB.IntParam.OutputFlag, 0);
            env.set(GRB.IntParam.Seed, Base.SEED);
            env.set(GRB.IntParam.Threads, Param.nThreads);
            env.set(GRB.IntParam.LogToConsole, 0);
            env.start();
            buildModelStage1();
            modelStage1.set(GRB.DoubleParam.TimeLimit, timeLimit);
            modelStage1.optimize();
            timeOnOptimizeModelStage1 = modelStage1.get(GRB.DoubleAttr.Runtime);
            // System.out.println("the time on Optimize Model Stage1:" + timeOnOptimizeModelStage1);
            int L = 0;
            if (modelStage1.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL) {
                stage1Optimal = true;
                for (int i = 0; i < N; i++) {
                    if (Base.roundToInt(y[i].get(GRB.DoubleAttr.X)) == 1.0) {
                        L++;
                    }
                }
            } else {
                stage1Optimal = false;
                return;
            }


            buildModelStage2(L);
            modelStage2.set(GRB.DoubleParam.TimeLimit, timeLimit - timeOnOptimizeModelStage1);
            modelStage2.optimize();
            timeOnOptimizeModelStage2 = modelStage2.get(GRB.DoubleAttr.Runtime);
            if (modelStage2.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL
                    || (modelStage2.get(GRB.IntAttr.Status) == GRB.Status.TIME_LIMIT && (modelStage2.get(GRB.IntAttr.SolCount) > 0))
                    || modelStage2.get(GRB.IntAttr.Status) == GRB.Status.SUBOPTIMAL) {
                solution = getSolution(L);
                feasible = solution.isFeasible(instance);
                if (feasible && Param.debug) {
                    System.out.println(solution.toString());
                }
            }
            if (modelStage2.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL) {
                optimal = true;
            } else {
                optimal = false;
            }

            if (Param.debug == true) {
                System.out.println(generateSolveResultCsvLine());
            }
        } catch (GRBException e) {
            throw new RuntimeException(e);
        }
    }

    public Solution getSolution(int L) throws GRBException {
        Solution solution = new Solution();
        for (int j = 0; j < L; j++) {
            Block block = new Block();
            for (int i = 0; i < N; i++) {
                if (Base.roundToInt(x[i][j].get(GRB.DoubleAttr.X)) == 1.0) {
                    block.add(i, instance);
                }
                // System.out.println("x_" + i + j + ":"  + Base.roundToInt(x[i][j].get(GRB.DoubleAttr.X)));
            }
            solution.add(block);
        }
        solution.computeMakespan(instance);
        return solution;
    }


    public void end() throws GRBException {
        modelStage1.dispose();
        if (modelStage2 != null) {
            modelStage2.dispose();
        }
        env.dispose();
    }

    public String generateSolveResultCsvLine() throws GRBException {
        boolean hasStage2 = (modelStage2 != null) && (modelStage2.get(GRB.IntAttr.SolCount) > 0
                || modelStage2.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL
                || modelStage2.get(GRB.IntAttr.Status) == GRB.Status.TIME_LIMIT
                || modelStage2.get(GRB.IntAttr.Status) == GRB.Status.SUBOPTIMAL);

        String noSolution = "无解";
        String str = instance.instName + ","
                + instance.nJobs + ","
                + instance.T + ","
                + instance.t + ","
                + Param.nThreads + ","
                + timeLimit + ","
                + String.format("%d", feasible == true  ? 1 : 0) + ","
                + String.format("%d", optimal == true ? 1 : 0) + ","
                + (hasStage2 ? Base.ceilToInt(modelStage2.get(GRB.DoubleAttr.ObjVal)) : noSolution) + ","
                + (hasStage2 ? Base.ceilToInt(modelStage2.get(GRB.DoubleAttr.ObjBound)) : noSolution) + ","
                + (hasStage2 ? String.format("%.3f", 100 * modelStage2.get(GRB.DoubleAttr.MIPGap)) : noSolution) + ","
                + String.format("%d", stage1Optimal == true ? 1 : 0) + ","
                + String.format("%.3f", timeOnBuildModelStage1 + timeOnOptimizeModelStage1 +
                timeOnBuildModelStage2 + timeOnOptimizeModelStage2) + ","
                + String.format("%.3f", timeOnBuildModelStage1) + ","
                + String.format("%.3f", timeOnOptimizeModelStage1) + ","
                + (int) modelStage1.get(GRB.DoubleAttr.NodeCount) + ","
                + modelStage1.get(GRB.IntAttr.NumVars) + ","
                + modelStage1.get(GRB.IntAttr.NumConstrs) + ","
                + modelStage1.get(GRB.IntAttr.Status) + ","
                + String.format("%.3f", timeOnBuildModelStage2) + ","
                + String.format("%.3f", timeOnOptimizeModelStage2) + ","
                + (hasStage2 ? (int) modelStage2.get(GRB.DoubleAttr.NodeCount) : noSolution) + ","
                + (hasStage2 ? modelStage2.get(GRB.IntAttr.NumVars) : noSolution) + ","
                + (hasStage2 ? modelStage2.get(GRB.IntAttr.NumConstrs) : noSolution) + ","
                + (hasStage2 ? modelStage2.get(GRB.IntAttr.Status) : noSolution);
        return str;
    }

}
