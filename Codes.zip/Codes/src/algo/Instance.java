package algo;

public class Instance implements Comparable<Instance> {
    public String instName;
    public int nJobs;
    public int[] p;
    public int T;
    public int t;

    public int id;      // 解析自文件名（如 "L_00000450" → 450 或 "L_00000450_T50" → 450）
    public int tValue;  // T值（旧格式默认为0，新格式解析为实际值）

    public Instance(Data data) {
        this.instName = data.instName;
        this.nJobs = data.nJobs;
        this.p = data.p;
        this.T = data.T;
        this.t = data.t;

        // 解析文件名（兼容两种格式）
        String[] parts = instName.split("_");
        this.id = Integer.parseInt(parts[1]); // 提取ID部分（如 "00000450" → 450）

        // 判断是否为带T值的格式（如 "L_XXXXXX_TYYY"）
        if (parts.length >= 3 && parts[2].startsWith("T")) {
            this.tValue = Integer.parseInt(parts[2].substring(1)); // 提取T值（如 "T50" → 50）
        } else {
            this.tValue = 0; // 旧格式默认T值为0
        }
    }

    @Override
    public int compareTo(Instance o) {
        // 优先按ID排序，再按T值排序
        int idCompare = Integer.compare(this.id, o.id);
        if (idCompare != 0) {
            return idCompare;
        }
        return Integer.compare(this.tValue, o.tValue);
    }

    public double mergedWeight(int[] a) {
        double sum = 0;
        for (int item : a) {
            sum += p[item];
        }
        return sum;
    }
}