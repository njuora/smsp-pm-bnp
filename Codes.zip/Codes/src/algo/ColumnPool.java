package algo;

import java.util.ArrayList;

public class ColumnPool extends ArrayList<Block> {
}
