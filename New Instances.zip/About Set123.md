### Set1

To expand the instance size, we consider:  
$n = 350, 400, 450, 500$. The value of $T$ still follows a uniform distribution over $[50, 100]$.  
For each value of $n$, 10 instances are generated, resulting in a new instance set named **Set1**.

### Set2

Fix $n = 100$, let the processing time $p$ follow a uniform distribution over $[20, 50]$, and set $T = 100$.  
A total of 10 instances are generated for this configuration, forming **Set2**.

### Set3

For the first 10 instances with $n = 100$ from the LOW dataset, we keep their original $p$ values.  
The value of $T$ is varied from 50 to 200 in increments, resulting in 16 different $T$ values per instance.  
In total, **Set3** contains $10 \times 16 = 160$ instances, used to analyze the impact of different $T$ values on algorithm performance.